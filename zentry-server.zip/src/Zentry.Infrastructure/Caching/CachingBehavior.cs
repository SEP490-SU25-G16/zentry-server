namespace Zentry.Infrastructure.Caching;

public class CachingBehavior
{
}
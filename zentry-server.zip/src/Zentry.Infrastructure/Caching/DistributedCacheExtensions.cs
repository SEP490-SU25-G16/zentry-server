namespace Zentry.Infrastructure.Caching;

public class DistributedCacheExtensions
{
}
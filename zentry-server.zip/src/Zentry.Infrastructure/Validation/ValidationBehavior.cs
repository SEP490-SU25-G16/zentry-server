namespace Zentry.Infrastructure.Validation;

public class ValidationBehavior
{
}
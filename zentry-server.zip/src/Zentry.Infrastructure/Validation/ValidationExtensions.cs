namespace Zentry.Infrastructure.Validation;

public class ValidationExtensions
{
}
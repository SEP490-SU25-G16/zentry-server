namespace Zentry.Infrastructure.Messaging.External;

public class MessageBrokerSettings
{
}
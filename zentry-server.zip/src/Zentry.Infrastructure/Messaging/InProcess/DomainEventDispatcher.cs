namespace Zentry.Infrastructure.Messaging.InProcess;

public class DomainEventDispatcher
{
}
namespace Zentry.Infrastructure.Security.Encryption;

public class DataProtectionService
{
}
namespace Zentry.Infrastructure.Security.Jwt;

public class JwtSettings
{
}
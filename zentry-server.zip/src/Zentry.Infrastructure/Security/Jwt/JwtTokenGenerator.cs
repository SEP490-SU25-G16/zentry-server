namespace Zentry.Infrastructure.Security.Jwt;

public class JwtTokenGenerator
{
}
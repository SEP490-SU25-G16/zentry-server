namespace Zentry.Modules.AttendanceManagement.Domain.Enums;

public enum SessionStatus
{
    Pending,
    Active,
    Completed,
    Cancelled,
    Archived
}
using Microsoft.EntityFrameworkCore;
using Zentry.Modules.AttendanceManagement.Application.Abstractions;
using Zentry.Modules.AttendanceManagement.Domain.Entities;
using Zentry.Modules.AttendanceManagement.Infrastructure.Persistence;

namespace Zentry.Modules.AttendanceManagement.Infrastructure.Repositories;

public class RoundRepository(AttendanceDbContext dbContext) : IRoundRepository
{
    public async Task AddAsync(Round entity, CancellationToken cancellationToken)
    {
        await dbContext.Rounds.AddAsync(entity, cancellationToken);
    }

    public async Task AddRangeAsync(IEnumerable<Round> entities, CancellationToken cancellationToken)
    {
        await dbContext.Rounds.AddRangeAsync(entities, cancellationToken);
    }

    public async Task<IEnumerable<Round>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await dbContext.Rounds.ToListAsync(cancellationToken);
    }

    public async Task<Round?> GetByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        return await dbContext.Rounds.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);
    }

    public async Task UpdateAsync(Round entity, CancellationToken cancellationToken)
    {
        dbContext.Rounds.Update(entity);
        await SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(Round entity, CancellationToken cancellationToken)
    {
        dbContext.Rounds.Remove(entity);
        await SaveChangesAsync(cancellationToken);
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task<List<Round>> GetRoundsBySessionIdAsync(Guid sessionId,
        CancellationToken cancellationToken = default)
    {
        return await dbContext.Rounds
            .Where(r => r.SessionId == sessionId)
            .OrderBy(r => r.RoundNumber)
            .ToListAsync(cancellationToken);
    }
}

﻿namespace Zentry.Modules.ConfigurationManagement.Dtos;

public class GetSettingsRequest
{
    public Guid? AttributeId { get; init; }
    public string? ScopeType { get; init; }
    public Guid? ScopeId { get; init; }
    public string? SearchTerm { get; init; }
    public int PageNumber { get; init; } = 1; // Giá trị mặc định
    public int PageSize { get; init; } = 10; // Giá trị mặc định
}
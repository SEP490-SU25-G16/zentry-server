namespace Zentry.Modules.DeviceManagement.Dtos;

public class DeviceDto
{
}
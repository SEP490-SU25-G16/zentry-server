﻿namespace Zentry.Modules.UserManagement.Features.UpdateUser;

public class UpdateUserRequest
{
    public string? FullName { get; set; }
    public string? PhoneNumber { get; set; }
    public string? Role { get; set; }
}
﻿namespace Zentry.Modules.ScheduleManagement.Application.Features.UpdateCourse;

public class UpdateCourseRequest
{
    public string? Name { get; set; }
    public string? Description { get; set; }
}
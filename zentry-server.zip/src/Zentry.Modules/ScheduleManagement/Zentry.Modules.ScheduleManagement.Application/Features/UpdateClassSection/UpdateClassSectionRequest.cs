namespace Zentry.Modules.ScheduleManagement.Application.Features.UpdateClassSection;

public class UpdateClassSectionRequest
{
    public string? SectionCode { get; set; }
    public string? Semester { get; set; }
}
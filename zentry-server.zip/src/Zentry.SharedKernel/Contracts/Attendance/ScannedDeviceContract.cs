namespace Zentry.SharedKernel.Contracts.Attendance;

public record ScannedDeviceContract(string DeviceId, int Rssi);
namespace Zentry.SharedKernel.Abstractions.Domain;

public interface IValueObject
{
}